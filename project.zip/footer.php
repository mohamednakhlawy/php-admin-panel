<div id="footer">
	&copy;2013-2016 BeMo Academic Consulting Inc. All rights reserved.
	<a href="http://www.cdainterview.com/disclaimer-privacy-policy.html" target="_blank"><span style="text-decoration:underline;">Disclaimer & Privacy Policy</span></a>
	<a href="mailto:info@bemoacademicconsulting.com" id="rw_email_contact"><span style="text-decoration:underline;">Contact Us</span></a>
</div>

<div id="socialicons">
	<div id="socialicons1"></div>
</div>
