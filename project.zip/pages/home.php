<!-- Stacks v1198 -->
<div id='stacks_out_7815_page0' class='stacks_top'>
	<div id='stacks_in_7815_page0' class=''>
		<div id='stacks_out_7822_page0' class='stacks_out'>
			<div id='stacks_in_7822_page0' class='stacks_in com_joeworkman_stacks_justifytext_stack'>
				<!-- Justify Text v1.0.7 Copyright @2010-2012 Joe Workman -->
				<?= base64_decode($page['content']); ?>
			</div>
		</div>
	</div>
</div>
<!-- End of Stacks Content -->
