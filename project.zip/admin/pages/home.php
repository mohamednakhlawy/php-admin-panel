<div class="row">
	<div class="col-md-12">
	    <div class="card">
	        <div class="card-header">
	            <strong class="card-title">Note</strong>
	        </div>
	        <div class="card-body">
	            <p class="card-text">Developed by Mohamed Nakhlawy</p>
	        </div>
	    </div>
	</div>
</div>
